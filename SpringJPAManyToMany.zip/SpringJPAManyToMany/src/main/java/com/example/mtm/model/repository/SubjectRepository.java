package com.example.mtm.model.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mtm.model.Subject;
 

public interface SubjectRepository extends JpaRepository<Subject, Integer>{
}